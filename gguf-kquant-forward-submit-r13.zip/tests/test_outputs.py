"""Verifier for gguf-kquant-forward.

The submitted /app/run.py is executed as the unprivileged `runner` user with the NumPy-only
candidate interpreter. It is given a GGUF model and a token sequence and must write a float32
(n_tokens, vocab) logits array. Every output is compared against sealed golden logits with
numpy.allclose(out, ref, rtol=1e-3, atol=1e-3).

Visible cases use the verifier's own copies of the two shipped models. Held-out cases use
models the agent never sees; they vary shapes, head grouping, quant mixes, tensor order,
alignment, rope base and tying within the documented domain.
"""

import ctypes
import io
import json
import os
import pwd
import shutil
import stat
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import pytest

CASES = json.loads(Path("/tests/cases.json").read_text())
INPUTS = Path("/srv/gk-inputs")
GOLDENS = Path("/tests/goldens")
RUN_PY = Path("/app/run.py")
# The NumPy-only interpreter, invoked under the documented name python3.
PY = "/opt/candidate/bin/python3"
RTOL = ATOL = 1e-3

VISIBLE = [c for c in CASES if c["visible"]]
HELDOUT = [c for c in CASES if not c["visible"]]


_LIBC = ctypes.CDLL(None, use_errno=True)
PR_SET_NO_NEW_PRIVS = 38


def _no_new_privs():
    """Runs in the child just before exec. From here on no exec can add privileges, so a setuid
    or setgid file, or one carrying file capabilities, runs with the runner's own rights."""
    zero = ctypes.c_ulong(0)
    if _LIBC.prctl(PR_SET_NO_NEW_PRIVS, ctypes.c_ulong(1), zero, zero, zero) != 0:
        raise OSError(ctypes.get_errno(), "prctl(PR_SET_NO_NEW_PRIVS) failed")


def _harden_tree(root):
    """Make a delivered tree root-owned, readable and not writable by the runner account, and
    leave nothing in it that could lend a process more rights than its own: setuid and setgid
    bits are cleared, and device nodes, FIFOs and sockets are removed. Symlinks are left alone."""
    entries = [str(root)]
    for dirpath, dirnames, filenames in os.walk(root):
        entries += [os.path.join(dirpath, name) for name in (*dirnames, *filenames)]
    for path in entries:
        st = os.lstat(path)
        if stat.S_ISLNK(st.st_mode):
            continue
        if not (stat.S_ISREG(st.st_mode) or stat.S_ISDIR(st.st_mode)):
            os.unlink(path)
            continue
        os.chown(path, 0, 0)
        mode = stat.S_IMODE(st.st_mode) & ~(
            stat.S_ISUID | stat.S_ISGID | stat.S_IWGRP | stat.S_IWOTH
        )
        mode |= stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH
        if stat.S_ISDIR(st.st_mode) or mode & (
            stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
        ):
            mode |= stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
        os.chmod(path, mode)


@pytest.fixture(scope="session", autouse=True)
def _readable_app():
    """Before any case runs, make the delivered /app tree readable (not writable) by the runner
    account and strip it of setuid and setgid bits and of special files."""
    if Path("/app").is_dir() and not Path("/app").is_symlink():
        _harden_tree("/app")
    yield


def _runner_env(home):
    return {
        "PATH": "/opt/candidate/bin:/usr/local/bin:/usr/bin:/bin",
        "HOME": home,
        "OMP_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONNOUSERSITE": "1",
    }


def _as_runner(argv, workdir):
    return subprocess.run(
        argv,
        cwd=workdir,
        env=_runner_env(workdir),
        user="runner",
        group="runner",
        extra_groups=[],
        preexec_fn=_no_new_privs,
        capture_output=True,
        text=True,
        check=False,
    )


def _workdir():
    d = tempfile.mkdtemp(prefix="gk-", dir="/tmp")
    pw = pwd.getpwnam("runner")
    os.chown(d, pw.pw_uid, pw.pw_gid)
    os.chmod(d, 0o700)
    return d


def _read_as_runner(path, workdir):
    """Read the output the way the program's own account sees it: links are followed with the
    runner's permissions, so nothing it cannot read itself can be passed off as its output."""
    r = subprocess.run(
        [
            PY,
            "-c",
            "import shutil, sys\nwith open(sys.argv[1], 'rb') as f:\n    shutil.copyfileobj(f, sys.stdout.buffer)",
            path,
        ],
        cwd=workdir,
        env=_runner_env(workdir),
        user="runner",
        group="runner",
        extra_groups=[],
        preexec_fn=_no_new_privs,
        capture_output=True,
        check=False,
    )
    assert r.returncode == 0, (
        f"output {path} is not readable: {r.stderr.decode(errors='replace')[-500:]}"
    )
    return np.load(io.BytesIO(r.stdout), allow_pickle=False)


def _out_path(case, workdir):
    """--out is a per-case path in a results subdirectory of the working directory; every other
    case uses a name without the .npy suffix, which must be written exactly as given."""
    d = os.path.join(workdir, "results", case["id"])
    os.makedirs(d)
    pw = pwd.getpwnam("runner")
    for p in (os.path.join(workdir, "results"), d):
        os.chown(p, pw.pw_uid, pw.pw_gid)
    name = f"{case['id']}.npy" if CASES.index(case) % 2 == 0 else f"{case['id']}-logits"
    return os.path.join(d, name)


def _check_case(case):
    assert RUN_PY.is_file(), "/app/run.py is missing"
    wd = _workdir()
    out = _out_path(case, wd)
    argv = [
        PY,
        str(RUN_PY),
        "--model",
        str(INPUTS / case["model"]),
        "--tokens",
        ",".join(str(t) for t in case["tokens"]),
        "--out",
        out,
    ]
    r = _as_runner(argv, wd)
    assert r.returncode == 0, f"run.py exited {r.returncode}: {r.stderr[-2000:]}"
    got = _read_as_runner(out, wd)
    ref = np.load(GOLDENS / f"{case['id']}.npy")
    assert got.dtype == np.float32, f"dtype {got.dtype}, expected float32"
    assert got.shape == ref.shape, f"shape {got.shape}, expected {ref.shape}"
    assert np.isfinite(got).all(), "non-finite logits"
    err = np.abs(got.astype(np.float64) - ref) - (ATOL + RTOL * np.abs(ref))
    worst = np.unravel_index(int(np.argmax(err)), err.shape)
    assert np.allclose(got, ref, rtol=RTOL, atol=ATOL), (
        f"logits outside rtol=atol=1e-3; worst at position {worst[0]}, token {worst[1]}: "
        f"got {got[worst]:.6f}, expected {ref[worst]:.6f}"
    )


def test_answer_tree_is_sealed_from_runner():
    """The runner account cannot read the golden logits or the case list, so answers must be
    computed. A setuid-root program does not change that: one planted here and started the way
    run.py is started gets no extra rights, because candidate processes run with no_new_privs."""
    wd = _workdir()
    probe = (
        "import sys\nfor p in sys.argv[1:]:\n    try:\n        open(p, 'rb').read(1)\n"
        "        print('READABLE', p)\n    except OSError:\n        pass\n"
    )
    targets = [
        str(GOLDENS / f"{CASES[0]['id']}.npy"),
        "/tests/cases.json",
        "/tests/test_outputs.py",
    ]
    r = _as_runner([PY, "-c", probe, *targets], wd)
    assert r.returncode == 0, r.stderr
    assert "READABLE" not in r.stdout, r.stdout
    helper = os.path.join(wd, "setuid-cat")
    shutil.copyfile("/bin/cat", helper)
    os.chown(helper, 0, 0)
    os.chmod(helper, 0o4755)
    for target in targets:
        r = subprocess.run(
            [helper, target],
            cwd=wd,
            env=_runner_env(wd),
            user="runner",
            group="runner",
            extra_groups=[],
            preexec_fn=_no_new_privs,
            capture_output=True,
            check=False,
        )
        assert r.returncode != 0 and not r.stdout, (
            f"a setuid-root program let the runner read {target}"
        )


def test_delivered_tree_is_stripped_of_privilege_carriers():
    """What the verifier does to /app before the first case, applied to a tree built here: a
    setuid file, a setgid directory and a FIFO go in; afterwards no setuid or setgid bit is left,
    the FIFO is gone, everything is root-owned and readable, and nothing is writable by the
    runner. /app itself is checked the same way."""
    root = tempfile.mkdtemp(prefix="gk-tree-", dir="/tmp")
    sub = os.path.join(root, "pkg")
    os.mkdir(sub)
    planted = os.path.join(sub, "helper")
    shutil.copyfile("/bin/cat", planted)
    pw = pwd.getpwnam("runner")
    os.chown(planted, pw.pw_uid, pw.pw_gid)
    os.chmod(planted, 0o6777)
    os.chmod(sub, 0o2777)
    os.mkfifo(os.path.join(sub, "pipe"))
    _harden_tree(root)
    assert not os.path.lexists(os.path.join(sub, "pipe")), "a FIFO survived"
    for tree in (root, "/app"):
        for dirpath, dirnames, filenames in os.walk(tree):
            for name in (*dirnames, *filenames):
                st = os.lstat(os.path.join(dirpath, name))
                if stat.S_ISLNK(st.st_mode):
                    continue
                assert stat.S_ISREG(st.st_mode) or stat.S_ISDIR(st.st_mode), (
                    f"special file {name} in {tree}"
                )
                assert not st.st_mode & (stat.S_ISUID | stat.S_ISGID), (
                    f"setuid/setgid bit on {name} in {tree}"
                )
                assert st.st_uid == 0 and not st.st_mode & (
                    stat.S_IWGRP | stat.S_IWOTH
                ), f"{name} in {tree} is writable by the runner"
    shutil.rmtree(root)


@pytest.mark.parametrize("case", VISIBLE, ids=[c["id"] for c in VISIBLE])
def test_visible_model_logits(case):
    """Logits for the shipped models match the reference: tiny-llama isolates Q4_K and Q6_K decoding,
    interleaved (llama) rope, 4:1 grouped-query attention, an untied output matrix reading the rms
    epsilon from metadata and a missing rope.dimension_count key (defaults to the head dimension); tiny-qwen2 isolates Q8_0, F16 and F32-matrix decoding, NEOX (qwen2) rope, 2:1 grouped-query attention, q/k/v
    biases, tied output embeddings, rope freq_base from metadata, general.alignment 256 and the
    4096-token vocabulary limit. tiny-llama-0 is a single token. Both contain non-square matrices,
    so GGUF dimension order must be honoured. Token ids are random, with the extreme ids placed
    away from the ends."""
    _check_case(case)


@pytest.mark.parametrize("case", HELDOUT, ids=[c["id"] for c in HELDOUT])
def test_heldout_model_logits(case):
    """Logits for unseen models match the reference. Query/KV head counts: h-llama-gqa 8/2 (Q4_K/Q6_K,
    untied, alignment 32), h-qwen2-mixed 16/4 (Q4_K/Q6_K/Q8_0/F16, untied, alignment 128),
    h-llama-mha 4/4 (F16/Q8_0, tied, alignment 64, rope base 5e5), h-llama-wide 6/2 (F16/Q8_0 with an
    F32 matrix, the 4096-token vocabulary limit, alignment 512, a one-token sequence),
    h-group-5to1 10/2, h-group-6to1 12/2, h-group-7to1 14/2 and h-group-8to1 16/2 (one layer each),
    h-kv3 6/3 (a KV-head count that is not a power of two), h-qwen2-mqa 8/1 (Q4_K/Q6_K, tied,
    default alignment, no rope.dimension_count key), and two groups larger than eight over one KV head:
    h-group-9to1 9/1 (llama, F32/F16/Q8_0, untied, alignment 64) and h-group-16to1 16/1 (qwen2,
    F16/Q8_0, tied, default alignment, no rope.dimension_count key). h-heads-1 to h-heads-15 fill in every other query-head count
    from 1 to 16 (one layer each): 1/1 and 2/1 (llama, F32, head dimension 64), 3/3 (qwen2, tied,
    alignment 128), 5/5 (llama, alignment 256), 7/1 (qwen2, alignment 512), 11/11 (llama, head
    dimension 16, tied), 13/1 (qwen2, tied) and 15/5 (llama). The 29 h-pair-H-K models (one layer each, F32/F16/Q8_0,
    alternating llama and qwen2) supply every remaining pairing of H query heads with K KV heads, so all
    50 pairings with K dividing H and H up to 16 are graded, including grouped attention over 5, 6, 7
    and 8 KV heads (10/5, 12/6, 14/7, 16/8). llama models carry no bias tensors and qwen2 models carry
    q/k/v biases only, as in the shipped examples. h-table-order holds the weights of
    h-qwen2-mixed with its tensor table listed in a different order from the tensor data, so a
    tensor has to be located by its recorded offset, not by its place in the table. Visible models: tiny-llama 8/2, tiny-qwen2 4/2.
    Sequences reach the 64-token limit and include the first and last vocabulary ids."""
    _check_case(case)
