#!/bin/bash
# Oracle: install the reference GGUF runner into /app, then sanity-check it against the
# shipped reference logits for both visible models.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -f "$HERE/run.py" ]; then
  echo "solution/run.py is missing" >&2
  exit 1
fi
cp "$HERE"/*.py /app/

cd /app
for tok in /app/models/reference/*.tokens; do
  base="${tok%.tokens}"
  model="/app/models/$(basename "$base" | sed 's/-[0-9]*$//').gguf"
  python3 /app/run.py --model "$model" --tokens "$(cat "$tok")" --out /tmp/oracle_check.npy
  python3 - "$base.logits.npy" <<'PY'
import sys
import numpy as np
ref = np.load(sys.argv[1])
got = np.load("/tmp/oracle_check.npy")
assert got.dtype == np.float32 and got.shape == ref.shape
assert np.allclose(got, ref, rtol=1e-3, atol=1e-3), sys.argv[1]
print("ok", sys.argv[1])
PY
done
rm -f /tmp/oracle_check.npy
