#!/usr/bin/env python3
import argparse
import math
import struct
from pathlib import Path

import numpy as np

GGML_F32 = 0
GGML_F16 = 1
GGML_Q8_0 = 8
GGML_Q4_K = 12
GGML_Q6_K = 14

_TYPE_LAYOUT = {
    GGML_F32: (1, 4),
    GGML_F16: (1, 2),
    GGML_Q8_0: (32, 34),
    GGML_Q4_K: (256, 144),
    GGML_Q6_K: (256, 210),
}


class GGUF:
    def __init__(self, path):
        self.path = Path(path)
        self.fp = self.path.open("rb")
        if self.fp.read(4) != b"GGUF":
            raise ValueError("not a GGUF file")
        self.version = self._unpack("<I")
        if self.version != 3:
            raise ValueError(f"unsupported GGUF version {self.version}")
        n_tensors = self._unpack("<Q")
        n_kv = self._unpack("<Q")
        self.metadata = {}
        for _ in range(n_kv):
            key = self._read_string()
            value_type = self._unpack("<I")
            self.metadata[key] = self._read_value(value_type)

        self.tensors = {}
        for _ in range(n_tensors):
            name = self._read_string()
            n_dims = self._unpack("<I")
            dims = tuple(self._unpack("<Q") for _ in range(n_dims))
            ggml_type = self._unpack("<I")
            offset = self._unpack("<Q")
            self.tensors[name] = (dims, ggml_type, offset)

        alignment = int(self.metadata.get("general.alignment", 32))
        end = self.fp.tell()
        self.data_offset = (end + alignment - 1) // alignment * alignment
        self._cache = {}

    def close(self):
        self.fp.close()

    def _unpack(self, fmt):
        n = struct.calcsize(fmt)
        raw = self.fp.read(n)
        if len(raw) != n:
            raise ValueError("truncated GGUF")
        return struct.unpack(fmt, raw)[0]

    def _read_string(self):
        n = self._unpack("<Q")
        raw = self.fp.read(n)
        if len(raw) != n:
            raise ValueError("truncated GGUF string")
        return raw.decode("utf-8")

    def _read_value(self, t):
        fmts = {
            0: "<B",
            1: "<b",
            2: "<H",
            3: "<h",
            4: "<I",
            5: "<i",
            6: "<f",
            7: "<?",
            10: "<Q",
            11: "<q",
            12: "<d",
        }
        if t == 8:
            return self._read_string()
        if t == 9:
            elem_type = self._unpack("<I")
            n = self._unpack("<Q")
            return [self._read_value(elem_type) for _ in range(n)]
        try:
            return self._unpack(fmts[t])
        except KeyError as exc:
            raise ValueError(f"unsupported GGUF metadata type {t}") from exc

    def tensor(self, name):
        if name in self._cache:
            return self._cache[name]
        if name not in self.tensors:
            raise KeyError(name)
        dims, ggml_type, offset = self.tensors[name]
        count = math.prod(dims)
        qk, block_bytes = _TYPE_LAYOUT[ggml_type]
        if count % qk:
            raise ValueError(f"tensor {name} has incompatible size for type {ggml_type}")
        nbytes = count // qk * block_bytes
        self.fp.seek(self.data_offset + offset)
        raw = self.fp.read(nbytes)
        if len(raw) != nbytes:
            raise ValueError(f"truncated tensor {name}")

        if ggml_type == GGML_F32:
            flat = np.frombuffer(raw, dtype="<f4").astype(np.float32, copy=True)
        elif ggml_type == GGML_F16:
            flat = np.frombuffer(raw, dtype="<f2").astype(np.float32)
        elif ggml_type == GGML_Q8_0:
            flat = dequant_q8_0(raw)
        elif ggml_type == GGML_Q4_K:
            flat = dequant_q4_k(raw)
        elif ggml_type == GGML_Q6_K:
            flat = dequant_q6_k(raw)
        else:
            raise ValueError(f"unsupported tensor type {ggml_type}")

        arr = flat.reshape(tuple(reversed(dims)))
        self._cache[name] = arr
        return arr


def dequant_q8_0(raw):
    blocks = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 34)
    d = blocks[:, :2].copy().view("<f2").reshape(-1).astype(np.float32)
    q = blocks[:, 2:].view(np.int8).astype(np.float32)
    return (q * d[:, None]).reshape(-1)


def _q4_scale_min(scales, j):
    if j < 4:
        scale = int(scales[j] & 0x3F)
        minimum = int(scales[j + 4] & 0x3F)
    else:
        scale = int((scales[j + 4] & 0x0F) | ((scales[j - 4] >> 6) << 4))
        minimum = int((scales[j + 4] >> 4) | ((scales[j] >> 6) << 4))
    return scale, minimum


def dequant_q4_k(raw):
    blocks = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 144)
    d = blocks[:, 0:2].copy().view("<f2").reshape(-1).astype(np.float32)
    dmin = blocks[:, 2:4].copy().view("<f2").reshape(-1).astype(np.float32)
    packed = blocks[:, 4:16]

    scales = np.empty((len(blocks), 8), dtype=np.uint8)
    mins = np.empty((len(blocks), 8), dtype=np.uint8)
    scales[:, :4] = packed[:, :4] & 0x3F
    mins[:, :4] = packed[:, 4:8] & 0x3F
    scales[:, 4:] = (packed[:, 8:12] & 0x0F) | ((packed[:, :4] >> 6) << 4)
    mins[:, 4:] = (packed[:, 8:12] >> 4) | ((packed[:, 4:8] >> 6) << 4)

    chunks = blocks[:, 16:144].reshape(-1, 4, 32)
    q = np.empty((len(blocks), 8, 32), dtype=np.uint8)
    q[:, 0::2, :] = chunks & 0x0F
    q[:, 1::2, :] = chunks >> 4
    values = (
        d[:, None, None] * scales[:, :, None].astype(np.float32) * q.astype(np.float32)
        - dmin[:, None, None] * mins[:, :, None].astype(np.float32)
    )
    return values.reshape(-1)


def dequant_q6_k(raw):
    blocks = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 210)
    ql = blocks[:, :128].reshape(-1, 2, 64)
    qh = blocks[:, 128:192].reshape(-1, 2, 32)
    scales = blocks[:, 192:208].view(np.int8).astype(np.float32).reshape(-1, 2, 8)
    d = blocks[:, 208:210].copy().view("<f2").reshape(-1).astype(np.float32)

    lo0 = ql[:, :, :32]
    lo1 = ql[:, :, 32:]
    q0 = (lo0 & 0x0F) | ((qh & 0x03) << 4)
    q1 = (lo1 & 0x0F) | (((qh >> 2) & 0x03) << 4)
    q2 = (lo0 >> 4) | (((qh >> 4) & 0x03) << 4)
    q3 = (lo1 >> 4) | (((qh >> 6) & 0x03) << 4)
    q = np.concatenate((q0, q1, q2, q3), axis=2).astype(np.float32) - 32.0

    s = np.concatenate(
        tuple(np.repeat(scales[:, :, i:i + 2], 16, axis=2) for i in (0, 2, 4, 6)),
        axis=2,
    )
    values = d[:, None, None] * s * q
    return values.reshape(-1)

def rms_norm(x, weight, eps):
    xd = x.astype(np.float64, copy=False)
    scale = 1.0 / np.sqrt(np.mean(xd * xd, axis=-1, keepdims=True) + eps)
    return (xd * scale) * weight.astype(np.float64, copy=False)


def silu(x):
    return x / (1.0 + np.exp(-x))


def apply_rope(x, positions, base, arch):
    # x: [tokens, heads, head_dim]
    _t, _h, d = x.shape
    half = d // 2
    inv = base ** (-np.arange(half, dtype=np.float64) * (2.0 / d))
    theta = positions.astype(np.float64)[:, None] * inv[None, :]
    c = np.cos(theta)[:, None, :]
    s = np.sin(theta)[:, None, :]
    out = np.empty_like(x, dtype=np.float64)
    if arch == "llama":
        even = x[..., 0::2]
        odd = x[..., 1::2]
        out[..., 0::2] = even * c - odd * s
        out[..., 1::2] = even * s + odd * c
    elif arch == "qwen2":
        a = x[..., :half]
        b = x[..., half:]
        out[..., :half] = a * c - b * s
        out[..., half:] = a * s + b * c
    else:
        raise ValueError(f"unsupported architecture {arch}")
    return out


def softmax(x, axis=-1):
    m = np.max(x, axis=axis, keepdims=True)
    e = np.exp(x - m)
    return e / np.sum(e, axis=axis, keepdims=True)


def linear(x, w, b=None):
    y = x @ w.astype(np.float64, copy=False).T
    if b is not None:
        y = y + b.astype(np.float64, copy=False)
    return y


def forward(model, tokens):
    md = model.metadata
    arch = md.get("general.architecture")
    if arch not in ("llama", "qwen2"):
        raise ValueError(f"unsupported architecture {arch!r}")

    prefix = arch + "."
    dim = int(md[prefix + "embedding_length"])
    n_layers = int(md[prefix + "block_count"])
    n_heads = int(md[prefix + "attention.head_count"])
    n_kv = int(md.get(prefix + "attention.head_count_kv", n_heads))
    # rope.dimension_count is optional; llama.cpp defaults it to the head dimension.
    rope_dim = int(md.get(prefix + "rope.dimension_count", dim // n_heads))
    if rope_dim * n_heads != dim:
        raise ValueError("rope/head dimension is outside task scope")
    head_dim = dim // n_heads
    eps = float(md[prefix + "attention.layer_norm_rms_epsilon"])
    rope_base = float(md.get(prefix + "rope.freq_base", 10000.0))
    if n_heads % n_kv:
        raise ValueError("invalid query/KV head grouping")

    emb = model.tensor("token_embd.weight")
    tok = np.asarray(tokens, dtype=np.int64)
    if np.any(tok < 0) or np.any(tok >= emb.shape[0]):
        raise ValueError("token id out of range")
    x = emb[tok].astype(np.float64)
    positions = np.arange(len(tok), dtype=np.float64)

    causal = np.triu(np.ones((len(tok), len(tok)), dtype=bool), k=1)
    for layer in range(n_layers):
        stem = f"blk.{layer}."
        residual = x
        xn = rms_norm(x, model.tensor(stem + "attn_norm.weight"), eps)
        qb = model.tensor(stem + "attn_q.bias") if stem + "attn_q.bias" in model.tensors else None
        kb = model.tensor(stem + "attn_k.bias") if stem + "attn_k.bias" in model.tensors else None
        vb = model.tensor(stem + "attn_v.bias") if stem + "attn_v.bias" in model.tensors else None
        q = linear(xn, model.tensor(stem + "attn_q.weight"), qb).reshape(len(tok), n_heads, head_dim)
        k = linear(xn, model.tensor(stem + "attn_k.weight"), kb).reshape(len(tok), n_kv, head_dim)
        v = linear(xn, model.tensor(stem + "attn_v.weight"), vb).reshape(len(tok), n_kv, head_dim)

        q = apply_rope(q, positions, rope_base, arch)
        k = apply_rope(k, positions, rope_base, arch)
        if n_kv != n_heads:
            repeat = n_heads // n_kv
            kq = np.repeat(k, repeat, axis=1)
            vq = np.repeat(v, repeat, axis=1)
        else:
            kq, vq = k, v

        # [heads, query, key]
        scores = np.einsum("qhd,khd->hqk", q, kq) / math.sqrt(head_dim)
        scores = np.where(causal[None, :, :], -np.inf, scores)
        probs = softmax(scores, axis=-1)
        ctx = np.einsum("hqk,khd->qhd", probs, vq).reshape(len(tok), dim)
        x = residual + linear(ctx, model.tensor(stem + "attn_output.weight"))

        residual = x
        xn = rms_norm(x, model.tensor(stem + "ffn_norm.weight"), eps)
        gate = linear(xn, model.tensor(stem + "ffn_gate.weight"))
        up = linear(xn, model.tensor(stem + "ffn_up.weight"))
        hidden = silu(gate) * up
        x = residual + linear(hidden, model.tensor(stem + "ffn_down.weight"))

    x = rms_norm(x, model.tensor("output_norm.weight"), eps)
    if "output.weight" in model.tensors:
        out_w = model.tensor("output.weight")
    else:
        out_w = emb
    return linear(x, out_w).astype(np.float32)


def parse_tokens(text):
    text = text.strip()
    if not text:
        return []
    return [int(part.strip()) for part in text.split(",")]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--tokens", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    tokens = parse_tokens(args.tokens)
    if not tokens:
        raise SystemExit("--tokens must contain at least one token id")
    if len(tokens) > 64:
        raise SystemExit("at most 64 tokens are supported")
    gguf = GGUF(args.model)
    try:
        logits = forward(gguf, tokens)
    finally:
        gguf.close()
    # np.save appends ".npy" to a bare filename string; write to the exact path given instead.
    with open(args.out, "wb") as f:
        np.save(f, logits.astype(np.float32, copy=False), allow_pickle=False)


if __name__ == "__main__":
    main()
