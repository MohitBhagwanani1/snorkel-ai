#!/bin/bash
set -uo pipefail
mkdir -p /logs/verifier
/opt/verifier/bin/python -m pytest --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA -p no:cacheprovider
rc=$?
if [ "$rc" -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
